import axios from "axios";
import React,{Component, useState} from "react";






function Contacts() {
  return (
    <div >
      <div class="body">
      <h1>contact -</h1><br></br>
      <p >deepakgera9112@gmail.com</p> 
      </div>
      <footer class="footer">
        <p>this is a footer</p>
      </footer>
    </div>
  );
}

export {Contacts};