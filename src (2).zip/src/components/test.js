// import {diljit} from "../musicoffline/diljit.jpg";
// import sharrymann from "../musicoffline/sharrymann.jpg";
// import jassigill from "../musicoffline/jassigill.jpg";
// import nehakakkar from "../musicoffline/nehakkr.jpg";

//  function test(){
  
//   let popartist=[diljit,sharrymann,jassigill,nehakakkar]
//   popartist.map((key)=>{
//     let s=JSON.stringify(key);
//     console.log(s);
//     let k=JSON.parse(key);
//     console.log(k);
// })
//  }
// test();
 

let obj={
    diljeet:"../musicoffline/diljit.jpg",
    nehakakkar:"../musicoffline/diljit.jpg",
    jassigill:"../musicoffline/diljit.jpg",
    sharrymann:"../musicoffline/diljit.jpg",
}
obj.map((o)=>{
console.log(o);
})