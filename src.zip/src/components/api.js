const YouTube = require('simple-youtube-api');
const youtube = new YouTube('AIzaSyB3HrRnv9q0LAGj-w25R-QU-j47HSS3GFc');
const getPopularList = async () => {
 var data= await youtube.searchVideos('never say never', 4)
            .catch((e) => {
               console.log(e);
  });
   return await data;
}
export const getSearchData = async (query) => {
   
   var data = await youtube.searchVideos(query + " song", 2).catch((e) => {
     console.log(e);
   });
 
   return await data;
};
export {getPopularList};    
    
    