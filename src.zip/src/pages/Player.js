import Card1 from "../components/Card1";
import React, { useState, useEffect } from "react";
import { Grid } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import ReactPlayer from "react-jinke-music-player";
import "react-jinke-music-player/assets/index.css";
import musiccover from "../musicoffline/Game.mp3";
import axios from "axios";
import { getPopularList } from "../components/api";

const useStyles = makeStyles({
  grid: {
    //paddingLeft:"40px",
    //paddingRight:"40px",
    // paddingTop:"40px",
    margin: "30px"

  }
})
/*getSongData = async (songId, title) => {
  try {
  var songUrl = await axios(`http://localhost:5000/download?URL=${songId}`);
    console.log(songUrl);} catch (e) {
      alert("Sorry Something Want Wrong Please Try Again");
    }
  }
*/
var GetpopularList = async () => {
  //const[songcover,setsongcover]=useState("");
  var tredingList = await getPopularList();
  var songid = tredingList[0].id;
  var songUrl = await axios(`http://localhost:5000/download?URL=${songid}`);
  console.log(songUrl);
  //setsongcover(songUrl.data);
  //console.log(songcover);

}
function Player() {
  //const [son,setson]=useState(musiccover);
  //setson(GetpopularList());

  const audiolist = [
    {
      musicSrc: musiccover,
      name: "Game",
      singer: "sidhubai"
    },
    {
      musicSrc: musiccover,
      name: "Game",
      singer: "sidhubai"
    },

  ]
  const [playsong, setplaysong] = useState(true);
  const classes = useStyles();
  return (
    <div>
      <Grid container spacing={4} className={classes.grid}>
        <Grid item xs={6} sm={6} md={4}>
          <Card1 />
        </Grid>
        <Grid item xs={6} sm={6} md={4}>
          <Card1 />
        </Grid>
        <Grid item xs={6} sm={6} md={4}>
          <Card1 />
        </Grid>
        <Grid item xs={6} sm={6} md={4}>
          <Card1 />
        </Grid>
      </Grid>
      {playsong ?
        <ReactPlayer audioLists={audiolist} />
        : undefined}
    </div>
  );
}

export { Player, GetpopularList };