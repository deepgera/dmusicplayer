
import React from "react";

function Playlist() {
  return (
    <div >
      <h1>this is playlist </h1>  
    </div>
  );
}

export {Playlist};