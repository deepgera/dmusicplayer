import './App.css';
import {Mainlayout} from "./layouts/Mainlayout";
import {Playlist} from "./pages/Playlist";
import {Player} from "./pages/Player";
import {Contacts} from "./pages/Contacts";
import React from "react";
import {
  BrowserRouter as Router,
  Switch,
  Route
} from "react-router-dom";



function App() {
  return (
    <div className="App">
    <Router>
      <Mainlayout/>
      <Switch>
      <Route path="/" exact>
        <Player/>
      </Route>
      <Route path="/Contacts" exact>
        <Contacts />
      </Route>
      <Route path="/Playlist" exact>
        <Playlist />
      </Route>
      </Switch>
    </Router>
    </div>
  );
}

export default App;
