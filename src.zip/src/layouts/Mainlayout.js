import { AppBar, Button, Drawer, IconButton, makeStyles, Toolbar, Typography } from "@material-ui/core";
import MenuIcon from '@material-ui/icons/Menu';
import React, { useState } from "react";
import InputBase from '@material-ui/core/InputBase';
import SearchIcon from '@material-ui/icons/Search';
import { Simplelist } from "../components/Simplelist";
import {Component} from "react";


const useStyles = makeStyles((theme) => ({
    root: {
      flexGrow: 1
    },
    menuButton: {
      marginRight: theme.spacing(4),
    },
    title: {
      textAlign: "left",
      flexGrow: 1,
    },
    drawerPaper: {
      width: 240,
    },
    drawer: {
      width:"100%",
      minwidth: 240,
    },
    searchIcon: {
      padding: "1px",
      height: '100%',
      position: "absolute",
      pointerEvents: 'none',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    },
    inputRoot: {
      color: 'inherit',
    },
    inputInput: {
      padding: theme.spacing(1, 1, 1, 0),
      // vertical padding + font size from searchIcon
      paddingLeft: `calc(1em + ${theme.spacing(4)}px)`,
      transition: theme.transitions.create('width'),
      width: '100%',
      [theme.breakpoints.up('sm')]: {
        width: '12ch',
        '&:focus': {
          width: '20ch',
        },
      },
    },
  }));
  
  function Mainlayout(){
  
  const[searchValue,setsearchValue]=useState(" ");
  const[ searchSongData,setsearchsongdata]=useState([]);
 
  const handlesearch=(event)=>{
    // console.log(`${event.target.value}`);
    setsearchValue( event.target.value );
   }
  const classes = useStyles();
  const [drawerOpen, setDrawerOpen] = useState(false);
      
    
    return (
      <div className={classes.root}>
        <AppBar position="fixed" >
          <Toolbar>
            <IconButton onClick={()=>{
              setDrawerOpen(!drawerOpen) }}
               edge="start" className={classes.menuButton} color="inherit" aria-label="menu">
              <MenuIcon />
            </IconButton>
            <Typography variant="h6"  className={classes.title}>
              Music Player
            </Typography>
            <div className={classes.search}>
            <div className={classes.searchIcon}>
              <SearchIcon  />
            </div>
            <InputBase
              placeholder="Search…"
              classes={{
                root: classes.inputRoot,
                input: classes.inputInput,
              }}
              onChange={handlesearch}
              inputProps={{ 'aria-label': 'search' }}
            />
          </div>
            <Button color="inherit">Login</Button>
          </Toolbar>
        </AppBar>
        <Drawer    classes={{paper: classes.drawerPaper}} className={classes.drawer} open={drawerOpen} onClose={() => setDrawerOpen(false)}>
        <Simplelist setDrawerOpen={setDrawerOpen}/>
       </Drawer>
      </div>
    );
  }
export {Mainlayout};
